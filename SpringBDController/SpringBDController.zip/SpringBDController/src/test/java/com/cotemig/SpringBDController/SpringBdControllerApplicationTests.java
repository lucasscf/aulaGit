package com.cotemig.SpringBDController;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBdControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
