package com.cotemig.SpringBDController;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBdControllerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBdControllerApplication.class, args);
	}

}
